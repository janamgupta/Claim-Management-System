import React from 'react';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';

class Main extends React.Component{

    render(){
        return(
           <div>
                {/* <Navbar collapseOnSelect expand="md" bg="dark" variant="dark">
                    <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                    <Navbar.Collapse id="responsive-navbar-nav">
                        <Nav className="mr-auto">
                            <Nav.Link href="#Home" active>Home</Nav.Link>
                            <Nav.Link href="#features">View Claim</Nav.Link>
                            <Nav.Link href="#pricing">Update Claim</Nav.Link>
                        </Nav>
                        <Nav>
                            <li className="nav-item">
                                <p className="mr-5 pt-2 user">Welcome, Abc</p>
                            </li>
                            <li>
                                <a className="btn btn-outline-light mt-1" href="login.html">Logout</a>
                            </li>
                        </Nav>
                    </Navbar.Collapse>
                </Navbar>  */}
              <div className="container mt-5 mb-5">
              <div className="row">
                <div className="col-lg-12 text-center">
                  <h1 className="mt-5">WELCOME</h1>
                  <p className="lead">View and Update Claim Summary</p>
                  <ul className="list-unstyled">
                    <li>View Claim</li>
                    <li>Update Claim</li>
                  </ul>
                </div>
              </div>
            </div>
        </div>
        );
    }
}
export default Main;