import React from 'react';
import AppRouter from './AppRoute.jsx';
class Main extends React.Component{

    render(){
        return(
           <div>
             <AppRouter></AppRouter>
              <div className="container mt-5 mb-5">
              <div className="row">
                <div className="col-lg-12 text-center">
                  <h1 className="mt-5">WELCOME</h1>
                  <p className="lead">View and Update Claim Summary</p>
                  <ul className="list-unstyled">
                    <li>View Claim</li>
                    <li>Update Claim</li>
                  </ul>
                </div>
              </div>
            </div>
        </div>
        );
    }
}
export default Main;