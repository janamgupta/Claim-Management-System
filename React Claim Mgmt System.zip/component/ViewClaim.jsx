import React from 'react';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Table from 'react-bootstrap/Table';
import ClaimList from './fetch.jsx';
import Link from 'react-router';
class ViewClaim extends React.Component {

    render() {
        let myStyle = {
            marginTop: "5rem",
            marginBottom: "5rem",
            marginLeft: "2rem"
        }
        return (
            <div>
                <Container>
                    <Row>
                        <Table bordered responsive="md" style={myStyle}>
                            <thead className="thead-dark">
                                <tr>
                                    <th scope="col">Employee Id</th>
                                    <th scope="col">Employee Name</th>
                                    <th scope="col">Claim Number</th>
                                    <th scope="col">Claim Type</th>
                                    <th scope="col">Claim Program</th>
                                    <th scope="col">Claim Start Date</th>
                                    <th scope="col">Claim End Date</th>
                                    <th scope="col">Update Claim</th>
                                </tr>
                            </thead>
                            <ClaimList/>
                        </Table>
                    </Row>
                </Container>
            </div>
        );
    }
}
export default ViewClaim;