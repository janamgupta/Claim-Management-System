import React from 'react';
import { Router, Route, Link, browserHistory, IndexRoute, Redirect }
    from 'react-router';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import Button from 'react-bootstrap/Button';
class AppRouter extends React.Component {
    constructor(props) {
       super(props); 
       this.state = {
            redirect: false
        };
    }
    setRedirect(){
        console.log("inside set redirect");
        let redirect = true;
        this.setState({redirect});
        this.renderRedirect();
    }
    renderRedirect(){
        console.log("inside render Redirect");
        if (this.state.redirect) {
            console.log("inside render Redirect true");
            return <Redirect to='login' />
        }
    }
    render() {
        return (
            <div>
                <Navbar collapseOnSelect expand="md" bg="dark" variant="dark">
                    <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                    <Navbar.Collapse id="responsive-navbar-nav">
                        <Nav className="mr-auto">
                            <Link to="home" className="nav-link">Home</Link>
                            <Link to="claim" className="nav-link">View Claim</Link>
                            <Link to="updateClaim" className="nav-link">Update Claim</Link>
                        </Nav>
                        <Nav>
                            <li className="nav-item">
                                <p className="mr-5 pt-2 user">Welcome, Abc</p>
                            </li>
                            <li>
                                <Button variant="outline-light" className="mt-1" onClick={()=>this.setRedirect()}>Logout</Button>
                            </li>
                        </Nav>
                    </Navbar.Collapse>
                </Navbar>
                {this.props.children};
            </div>
        )
    }
}

export default AppRouter;