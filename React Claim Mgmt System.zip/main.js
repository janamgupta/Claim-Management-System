import React from 'react';
import ReactDOM from 'react-dom';
import Login from './component/LoginComponent.jsx';
import Main from './component/MainComponent.jsx';
import ViewClaim from './component/ViewClaim.jsx';
import UpdateClaim from './component/UpdateClaim.jsx';
import AppRouter from './component/AppRoute.jsx';
import { Router, Route, Link, browserHistory, IndexRoute  } from 'react-router';

// ReactDOM.render(<Login/>, document.getElementById('login'));
// ReactDOM.render(<Main/>, document.getElementById('main'));
// ReactDOM.render(<ViewClaim/>, document.getElementById('view'));
//  ReactDOM.render(<UpdateClaim/>, document.getElementById('update'));
ReactDOM.render((
    <Router history = {browserHistory}>
    <Route path = "/" component = {AppRouter}>
           <IndexRoute component = {Main} />
           <Route path = "home" component = {Main} />
           <Route path = "claim" component = {ViewClaim} />
           <Route path = "updateClaim" component = {UpdateClaim} />
    </Route>
   </Router>
   ), document.getElementById('router'));
