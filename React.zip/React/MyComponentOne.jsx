import React from 'react';

class EmployeeName extends React.Component {

	render() {
    return(
        <div>Empname: {this.props.empname}</div>
     );
  }
}
export default EmployeeName;