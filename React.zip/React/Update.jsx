import React from 'react';

class Update extends React.Component {
   render() {
      return (
         <div>
            <h1>Update impl...</h1>
         </div>
      )
   }
}

export default Update ;
