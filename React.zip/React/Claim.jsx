import React from 'react';

class Claim extends React.Component {
   render() {
      return (
         <div>
            <h1>Details Claim list impl...</h1>
         </div>
      )
   }
}

export default Claim ;
