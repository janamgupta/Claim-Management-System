const sum = require('./sum.js')

test('adds 1 + 2 to eual 3', () =>{
    expect(sum(1, 2)).toBe(3);
})