import React from 'react';

class Hello extends React.Component {
   render() {
    let companies=['Birlasoft', 'IBM', 'US-Tech'];

    // style of the component here
    let myStyle = {
        fontSize: 50,
        color: '#FF0000'
    }
      return (
         <div>
            <p style={myStyle}>Hello World!!!</p>
            <h1>Expression:{2 + 4}</h1>
            <p>Name : {this.props.name}</p>
            <p>Age : {this.props.age}</p>

            <ul>
                {companies.map(function(company, index){
                    return <li key={ index }>{company}</li>
                })}
            </ul>
         </div>
      );
   }
}

export default Hello;   