import React from 'react';
import ReactDOM from 'react-dom';
import Hello from './App.jsx';
import Employee from './MyComponentTwo.jsx';
import MyStateComponent from './MyStateComponent.jsx';
import PersonList from './fetch.jsx';
import MyForm from './MyForm.jsx';
import Home from './Home.jsx';
import Claim from './Claim.jsx';
import Update from './Update.jsx';
import AppRouter from './AppRoute.jsx';
import { Router, Route, Link, browserHistory, IndexRoute  } from 'react-router';
//json object here
// let emp = { name: 'Ram',  city: 'Dubai'};
// ReactDOM.render(<Hello name="Janam" age="23"/>, document.getElementById('app'));
// ReactDOM.render(<Employee emp={emp}/>, document.getElementById('details'));
// ReactDOM.render(<MyStateComponent/>, document.getElementById('state'));
// ReactDOM.render(<PersonList/>, document.getElementById('person'));
// ReactDOM.render(<MyForm/>, document.getElementById('form'));
ReactDOM.render((
    <Router history = {browserHistory}>
    <Route path = "/" component = {AppRouter}>
           <IndexRoute component = {Home} />
           <Route path = "home" component = {Home} />
           <Route path = "claim" component = {Claim} />
           <Route path = "updateClaim" component = {Update} />
    </Route>
   </Router>
   ), document.getElementById('router'));