import React from 'react';
import AppRouter from './AppRoute.jsx';
class Main extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userName: ''
    };
  }
  componentDidMount() {
    let userName = localStorage.getItem('username');
    this.setState({userName});
  }
  render() {
    return (
      <div>
        <AppRouter username = {this.state.userName}></AppRouter>
        <div className="container mt-5 mb-5">
          <div className="row">
            <div className="col-lg-12 text-center">
              <h1 className="mt-5">WELCOME</h1>
              <p className="lead">View and Update Claim Summary</p>
              <ul className="list-unstyled">
                <li>View Claim</li>
                <li>Update Claim</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default Main;